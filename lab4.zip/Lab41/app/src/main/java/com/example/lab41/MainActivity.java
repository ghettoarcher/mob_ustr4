package com.example.lab41;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Fragment;
import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity implements Fragment1.onUrlEventListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Fragment fragment1 = new Fragment1();

    }


    @Override
    public void urlEvent(String url) {
        Fragment fragment2 = getFragmentManager().findFragmentById(R.id.fragment2);
        ((WebView)fragment2.getView().findViewById(R.id.webView)).loadUrl(url);
    }
}
