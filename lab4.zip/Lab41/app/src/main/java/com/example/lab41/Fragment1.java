package com.example.lab41;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import android.app.Fragment;

public class Fragment1 extends Fragment {

    public interface onUrlEventListener {
        public void urlEvent(String url);
    }

    onUrlEventListener urlEventListener;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            urlEventListener = (onUrlEventListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() +
                    " must implements onUrlEventListner");
        }
    }



    String[] domains = {"Google", "Facebook", "Instagram"};

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment1, null);

        ListView listView = (ListView) view.findViewById(R.id.listView);
        ArrayAdapter adapter = new ArrayAdapter<String>(this.getContext(), android.R.layout.simple_list_item_1,
                domains);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> a, View v, int position, long id) {
                String domain = domains[position];
                switch (domain) {
                    case "Google":
                        urlEventListener.urlEvent("https://www.google.com");
                        break;
                    case "Facebook":
                        urlEventListener.urlEvent("https://www.facebook.com");
                        break;
                    case "Instagram":
                        urlEventListener.urlEvent("https://www.instagram.com");
                        break;
                }
            }
        });

        return view;
    }
}
